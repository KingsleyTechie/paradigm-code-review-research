# Code Review Research Dataset

## Overview
Comprehensive dataset from empirical study on code review effectiveness across programming paradigms.

## Contents
- `primary/sessions.json` - 900 individual review sessions
- `primary/sessions.csv` - Tabular format of session data  
- `primary/paradigm-comparison.json` - Statistical comparisons
- `primary/defect-analysis.json` - Defect patterns by paradigm
- `complete-research-dataset.json` - Complete dataset structure
- `analysis/statistical-analysis.R` - R analysis script
- `analysis/python-analysis.py` - Python analysis script

## Research Context
This dataset supports the paper: "Code Review Effectiveness Across Programming Paradigms: An Empirical Analysis"

## Usage
```python
import pandas as pd
import json

with open('research-dataset/primary/sessions.json') as f:
    data = json.load(f)

df = pd.DataFrame(data)
print(f"Total sessions: {len(df)}")
```