
        # Python Analysis Script for Code Review Research
        import pandas as pd
        import matplotlib.pyplot as plt
        import seaborn as sns
        from scipy import stats
        import json
        
        # Load dataset
        with open('research-dataset/primary/sessions.json', 'r') as f:
            sessions = json.load(f)
        
        df = pd.DataFrame(sessions)
        
        print("=== RESEARCH DATASET ANALYSIS ===")
        print(f"Total sessions: {len(df)}")
        print(f"Participants: {df['participant_id'].nunique()}")
        
        # Paradigm comparison
        paradigm_stats = df.groupby('programming_paradigm').agg({
            'code_comprehension_time_ms': ['mean', 'std'],
            'defect_detection_rate': ['mean', 'std'],
            'participant_id': 'count'
        }).round(2)
        
        print("\nParadigm Performance Summary:")
        print(paradigm_stats)
        
        # Statistical testing
        paradigms = df['programming_paradigm'].unique()
        for paradigm in paradigms:
            paradigm_data = df[df['programming_paradigm'] == paradigm]
            print(f"\n{paradigm.upper()} - Mean comprehension: {paradigm_data['code_comprehension_time_ms'].mean():.0f}ms")
        
        # Visualization
        plt.figure(figsize=(10, 6))
        sns.boxplot(data=df, x='programming_paradigm', y='code_comprehension_time_ms')
        plt.title('Code Comprehension Time by Programming Paradigm')
        plt.savefig('research-dataset/analysis/comprehension_comparison.png')
        