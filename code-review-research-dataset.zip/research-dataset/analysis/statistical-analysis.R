
        # Statistical Analysis Script for Code Review Research
        library(jsonlite)
        library(dplyr)
        library(ggplot2)
        
        # Load dataset
        sessions <- fromJSON("research-dataset/primary/sessions.json")
        sessions_df <- as.data.frame(sessions)
        
        # Basic descriptive statistics
        cat("=== PARADIGM COMPARISON ===\n")
        sessions_df %>%
          group_by(programming_paradigm) %>%
          summarise(
            mean_comprehension = mean(code_comprehension_time_ms),
            mean_defect_rate = mean(defect_detection_rate),
            n = n()
          ) %>%
          print()
        
        # ANOVA test
        cat("\n=== ANOVA: Comprehension Time by Paradigm ===\n")
        anova_result <- aov(code_comprehension_time_ms ~ programming_paradigm, data = sessions_df)
        print(summary(anova_result))
        
        # Visualization
        ggplot(sessions_df, aes(x = programming_paradigm, y = code_comprehension_time_ms)) +
          geom_boxplot() +
          labs(title = "Comprehension Time by Programming Paradigm",
               x = "Programming Paradigm", y = "Comprehension Time (ms)")
        