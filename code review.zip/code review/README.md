# Code Review Research Platform

A web-based platform for empirical research on code review effectiveness across programming paradigms.

## Features

- **Multi-Paradigm Support**: Object-Oriented, Functional, and Procedural programming examples
- **Metrics Collection**: Comprehensive data collection on review times, defect identification, and comprehension
- **Research-Ready**: Designed for academic research with proper data validation
- **Easy Deployment**: Pure HTML/CSS/JS/PHP stack

## Setup Instructions

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/code-review-research-platform.git
   cd code-review-research-platform